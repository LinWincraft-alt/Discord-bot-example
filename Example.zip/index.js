//We import the librarian of discord.js
const Discord = require('discord.js');
const client = new Discord.Client();
const { Client, MessageEmbed } = require('discord.js');
const got = require('got');
require('dotenv').config()



//We're doing an event to turn on the Bot
client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
client.user.setActivity(process.env.PRESENCE)      
});


//We create a message event, so that the bot responds
client.on('message', msg => {
  //You have to replace !Ping with the word or phrase you want your bot to respond to
  if (msg.content === '!ping') {
    msg.reply('Pong!');
  }
});

//We create a message event, so that the bot responds
client.on('message', msg => {
  //You have to replace Ping with the word or phrase you want your bot to respond to
  if (msg.content === '!ping') {
    msg.reply('Pong!');
  }
});

//We create a message event, so that the bot responds
client.on('message', msg => {
  //You have to replace Ping with the word or phrase you want your bot to respond to
  if (msg.content === '!ping') {
    msg.reply('!Pong!');
  }
});

//We create a message event, so that the bot responds
client.on('message', msg => {
  //You have to replace Ping with the word or phrase you want your bot to respond to
  if (msg.content === '!ping') {
    msg.reply('Pong!');
  }
});

//𝕀𝕗 𝕪𝕠𝕦 𝕨𝕒𝕟𝕥 𝕞𝕠𝕣𝕖 𝕔𝕠𝕞𝕞𝕒𝕟𝕕𝕤 𝕛𝕦𝕤𝕥 𝕔𝕠𝕡𝕪 𝕥𝕙𝕖 𝕒𝕓𝕠𝕧𝕖 𝕒𝕟𝕕 𝕡𝕒𝕤𝕥𝕖 𝕚𝕥 𝟚 𝕝𝕚𝕟𝕖𝕤 𝕓𝕖𝕝𝕠𝕨, 𝕚𝕗 𝕚𝕥❜𝕤 𝕟𝕠𝕥 𝟚 𝕝𝕚𝕟𝕖𝕤 𝕥𝕙𝕖 𝕓𝕠𝕥 𝕨𝕠𝕟❜𝕥 𝕨𝕠𝕣𝕜













//███████╗███╗░░░███╗██████╗░███████╗██████╗░░██████╗
//██╔════╝████╗░████║██╔══██╗██╔════╝██╔══██╗██╔════╝
//█████╗░░██╔████╔██║██████╦╝█████╗░░██║░░██║╚█████╗░
//██╔══╝░░██║╚██╔╝██║██╔══██╗██╔══╝░░██║░░██║░╚═══██╗
//███████╗██║░╚═╝░██║██████╦╝███████╗██████╔╝██████╔╝
//╚══════╝╚═╝░░░░░╚═╝╚═════╝░╚══════╝╚═════╝░╚═════╝░

client.on('message', message => {
//You have to replace "embed" with the word or phrase you want to use
  if (message.content === '!embed') {
    const embed = new MessageEmbed()
//You have to replace "Embed Example" with the title of your embed
      .setTitle('Embed example')
      //If you don't know the colored codes you can get them here : https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
      .setColor(0xff0000)
      //You have to replace "embed" with the content you want your embed to have
      .setDescription('Embed');
    message.channel.send(embed);
  }
});

client.on('message', message => {
//You have to replace "embed" with the word or phrase you want to use
  if (message.content === '!embed') {
    const embed = new MessageEmbed()
//You have to replace "Embed Example" with the title of your embed
      .setTitle('Embed example')
      //If you don't know the colored codes you can get them here : https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
      .setColor(0xff0000)
      //You have to replace "embed" with the content you want your embed to have
      .setDescription('Embed');
    message.channel.send(embed);
  }
});












//
//██╗░░░░░░█████╗░░██████╗░██╗███╗░░██╗
//██║░░░░░██╔══██╗██╔════╝░██║████╗░██║
//██║░░░░░██║░░██║██║░░██╗░██║██╔██╗██║
//██║░░░░░██║░░██║██║░░╚██╗██║██║╚████║
//███████╗╚█████╔╝╚██████╔╝██║██║░╚███║
//╚══════╝░╚════╝░░╚═════╝░╚═╝╚═╝░░╚══╝




client.login(process.env.TOKEN)